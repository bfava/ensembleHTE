# Changelog

All notable changes to ensembleHTE will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial package structure
- Template functions for ensemble HTE estimation
- Documentation framework
- Testing infrastructure
- Vignettes

### Changed
- Nothing yet

### Deprecated
- Nothing yet

### Removed
- Nothing yet

### Fixed
- Nothing yet

### Security
- Nothing yet

## [0.1.0] - 2025-12-08

### Added
- Initial development version
- Core package structure
- Function templates for:
  - `ensemble_hte()`: Main fitting function
  - `predict.ensemble_hte()`: Prediction method
  - `summary.ensemble_hte()`: Summary method
  - Base learner implementations
  - Utility functions
  - Visualization tools
- Comprehensive documentation
- Test framework
- Development guide

[Unreleased]: https://github.com/bfava/ensembleHTE/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/bfava/ensembleHTE/releases/tag/v0.1.0
