#' Internal function to compute BLP for prediction (single repetition)
#' 
#' @param Y Outcome vector
#' @param predicted_y Predicted Y vector for this repetition
#' 
#' @return data.table with BLP estimates
#' @keywords internal
.blp_pred_single <- function(Y, predicted_y) {
  
  # Build data.table for BLP regression
  dt_blp <- data.table(
    Y = Y,
    predicted_y = predicted_y
  )
  
  # Build regression formula
  # BLP regression: Y ~ predicted_y
  formula_str <- "Y ~ predicted_y"
  
  # Run regression with robust SEs
  reg <- reg_from_formula(formula_str, dt_blp)
  coef_blp <- reg$coef
  
  # Extract estimates and SEs
  blp_estimates <- data.table(
    term = c("intercept", "beta"),
    estimate = coef_blp[c("(Intercept)", "predicted_y"), 1],
    se = coef_blp[c("(Intercept)", "predicted_y"), 2]
  )
  
  list(
    estimates = blp_estimates
  )
}


#' Compute BLP (Best Linear Predictor) for Prediction
#' 
#' @description
#' Computes the Best Linear Predictor (BLP) of the outcome using the ensemble
#' predictions. This is a simple regression of Y on the predicted Y values.
#' 
#' This function implements the multiple-split estimation strategy developed in
#' Fava (2025), which combines predictions from multiple machine learning algorithms
#' into an ensemble and averages BLP estimates across M repetitions of K-fold
#' cross-fitting to improve statistical power.
#' 
#' The method uses ordinary least squares regression of Y on predicted_Y.
#' A coefficient (beta) close to 1 indicates good calibration; significantly
#' different from 1 suggests over- or under-prediction.
#' 
#' @references
#' Fava, B. (2025). Training and Testing with Multiple Splits: A Central Limit
#' Theorem for Split-Sample Estimators. \emph{arXiv preprint arXiv:2511.04957}.
#' 
#' @param ensemble_fit An object of class `ensemble_pred_fit` from `ensemble_pred()`
#' @param outcome Either:
#'   \itemize{
#'     \item NULL (default): uses the same outcome as in `ensemble_pred()`
#'     \item Character string: column name in the `data` used in `ensemble_pred()`
#'     \item Numeric vector: custom outcome variable (must have same length as data)
#'   }
#'   This allows computing BLP for a different outcome than the one used for prediction.
#' 
#' @return An object of class `blp_pred_results` containing:
#' \itemize{
#'   \item estimates: data.table with BLP estimates averaged across repetitions
#'   \item outcome: outcome variable used
#'   \item targeted_outcome: original outcome from ensemble fitting
#'   \item M: number of repetitions
#'   \item call: the function call
#' }
#' 
#' @export
blp_pred <- function(ensemble_fit, outcome = NULL) {
  
  if (!inherits(ensemble_fit, "ensemble_pred_fit")) {
    stop("ensemble_fit must be of class 'ensemble_pred_fit' from ensemble_pred()")
  }
  
  cl <- match.call()
  
  # Get targeted outcome from ensemble_fit
  targeted_outcome <- all.vars(ensemble_fit$formula)[1]
  
  # Determine which outcome to use for BLP
  if (is.null(outcome)) {
    Y <- ensemble_fit$Y
    outcome_var <- targeted_outcome
  } else if (is.character(outcome)) {
    if (length(outcome) != 1) {
      stop("outcome must be a single column name or a numeric vector")
    }
    if (!outcome %in% names(ensemble_fit$data)) {
      stop(paste0("outcome '", outcome, "' not found in the data used for ensemble_pred()"))
    }
    Y <- ensemble_fit$data[[outcome]]
    outcome_var <- outcome
  } else if (is.numeric(outcome)) {
    if (length(outcome) != nrow(ensemble_fit$data)) {
      stop(paste0("outcome vector has length ", length(outcome), 
                  " but data has ", nrow(ensemble_fit$data), " rows"))
    }
    Y <- outcome
    outcome_var <- if (!is.null(names(outcome)) && names(outcome)[1] != "") {
      names(outcome)[1]
    } else {
      "custom_outcome"
    }
  } else {
    stop("outcome must be NULL, a character string, or a numeric vector")
  }
  
  # Extract components from ensemble_fit
  M <- ensemble_fit$M
  
  # Compute BLP for each repetition
  blp_by_rep <- lapply(1:M, function(m) {
    .blp_pred_single(
      Y = Y,
      predicted_y = ensemble_fit$predictions[[m]]
    )
  })
  
  # Combine estimates across repetitions
  all_estimates <- rbindlist(lapply(blp_by_rep, `[[`, "estimates"), idcol = "repetition")
  
  # Aggregate across repetitions: mean of estimates, mean of SE
  combined <- all_estimates[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = term]
  
  # Add t-values and p-values
  combined[, `:=`(
    t_value = estimate / se,
    p_value = 2 * pnorm(-abs(estimate / se))
  )]
  
  # Construct blp_pred_results object
  structure(
    list(
      estimates = combined,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      M = M,
      call = cl
    ),
    class = "blp_pred_results"
  )
}




# ==============================================================================
# Print methods
# ==============================================================================

#' Print method for blp_pred_results objects
#' @param x An object of class \code{blp_pred_results} from \code{blp_pred()}
#' @param ... Additional arguments (currently unused)
#' @export
print.blp_pred_results <- function(x, ...) {
  cat("BLP Results (Best Linear Predictor - Prediction)\n")
  cat("=================================================\n\n")
  
  # Show outcome information
  cat("Outcome analyzed:", x$outcome, "\n")
  if (x$outcome != x$targeted_outcome) {
    cat("Targeted outcome:", x$targeted_outcome, "\n")
  }
  cat("Repetitions:", x$M, "\n")
  
  cat("\nCoefficients:\n")
  cat("  intercept: Regression intercept (0 = well-calibrated)\n")
  cat("  beta: Prediction loading (1 = well-calibrated)\n\n")
  
  # Format output table
  out <- copy(x$estimates)
  out[, stars := get_stars(p_value)]
  
  # Print as formatted text
  cat(sprintf("  %10s  %10s  %10s  %8s  %10s\n", 
              "Term", "Estimate", "Std.Error", "t value", "Pr(>|t|)"))
  cat("  ", paste(rep("-", 52), collapse = ""), "\n", sep = "")
  for (i in 1:nrow(out)) {
    cat(sprintf("  %10s  %10.4f  %10.4f  %8.3f  %10.4f %s\n",
                out$term[i], out$estimate[i], out$se[i], 
                out$t_value[i], out$p_value[i], out$stars[i]))
  }
  
  cat("\n---\nSignif. codes: 0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1\n")
  invisible(x)
}
