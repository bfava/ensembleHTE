
#' Compute cross-regression covariance
#' 
#' @description
#' Computes the covariance between coefficient estimates from two different
#' regressions using the same data. This is needed to correctly compute the
#' standard error of the difference between estimates from two regressions.
#' 
#' @param X1 Model matrix from regression 1
#' @param X2 Model matrix from regression 2
#' @param resid1 Residuals from regression 1
#' @param resid2 Residuals from regression 2
#' 
#' @return Covariance matrix between coefficients of regression 1 (rows) and regression 2 (cols)
#' @keywords internal
.calc_cov_cross_reg <- function(X1, X2, resid1, resid2) {
  # (X1'X1)^{-1} X1'
  XtXinXt1 <- solve(t(X1) %*% X1) %*% t(X1)
  # (X2'X2)^{-1} X2'
  XtXinXt2 <- solve(t(X2) %*% X2) %*% t(X2)
  # Cov = (X1'X1)^{-1} X1' * diag(resid1 * resid2) * X2 (X2'X2)^{-1}
  cov <- XtXinXt1 %*% diag(resid1 * resid2) %*% t(XtXinXt2)
  return(cov)
}


#' Compute SE of difference between two regression coefficients
#' 
#' @description
#' Computes the estimate and standard error of the difference between
#' corresponding coefficients from two regressions (reg1 - reg2).
#' 
#' @param reg1 Result from reg_from_formula (list with coef, model_matrix, residuals)
#' @param reg2 Result from reg_from_formula (list with coef, model_matrix, residuals)
#' @param coef_name Name of the coefficient to compare
#' 
#' @return Named vector with 'estimate' and 'se'
#' @keywords internal
.calc_se_diff_regs <- function(reg1, reg2, coef_name) {
  # Get coefficient estimates and SEs
  est1 <- reg1$coef[coef_name, "Estimate"]
  se1 <- reg1$coef[coef_name, "Std. Error"]
  est2 <- reg2$coef[coef_name, "Estimate"]
  se2 <- reg2$coef[coef_name, "Std. Error"]
  
  # Compute cross-covariance
  cross_cov <- .calc_cov_cross_reg(
    reg1$model_matrix, reg2$model_matrix,
    reg1$residuals, reg2$residuals
  )
  
  # Get index for the coefficient in each regression
  idx1 <- which(rownames(reg1$coef) == coef_name)
  idx2 <- which(rownames(reg2$coef) == coef_name)
  
  # Estimate of difference
  diff_estimate <- est1 - est2
  
  # Variance of difference: var(A - B) = var(A) + var(B) - 2*cov(A,B)
  diff_var <- se1^2 + se2^2 - 2 * cross_cov[idx1, idx2]
  diff_se <- sqrt(max(diff_var, 0))  # Ensure non-negative
  
  c(estimate = diff_estimate, se = diff_se)
}


#' Compute difference between two regression results
#' 
#' @description
#' Computes the difference in group estimates and test statistics between two
#' regression results (e.g., unrestricted vs restricted ranking). Uses cross-regression
#' covariance for proper SE calculation when both regressions use the same data.
#' 
#' @param res1 Result from .gates_single or .gavs_single (first regression)
#' @param res2 Result from .gates_single or .gavs_single (second regression)
#' @param n_groups Number of groups
#' 
#' @return List with group_diff (differences in group estimates), top_bottom_diff, all_diff, top_all_diff
#' @keywords internal
.compute_reg_diff <- function(res1, res2, n_groups) {
  
  reg1 <- res1$reg
  reg2 <- res2$reg
  
  # Compute cross-covariance matrix
  cross_cov <- .calc_cov_cross_reg(
    reg1$model_matrix, reg2$model_matrix,
    reg1$residuals, reg2$residuals
  )
  
  group_cols <- paste0("group_", 1:n_groups)
  
  # Compute difference in group estimates
  group_diff <- data.table(group = 1:n_groups)
  for (g_idx in 1:n_groups) {
    col <- paste0("group_", g_idx)
    est1 <- reg1$coef[col, "Estimate"]
    se1 <- reg1$coef[col, "Std. Error"]
    est2 <- reg2$coef[col, "Estimate"]
    se2 <- reg2$coef[col, "Std. Error"]
    
    # Get indices
    idx1 <- which(rownames(reg1$coef) == col)
    idx2 <- which(rownames(reg2$coef) == col)
    
    # Variance of difference
    diff_var <- se1^2 + se2^2 - 2 * cross_cov[idx1, idx2]
    
    group_diff[g_idx, `:=`(
      estimate = est1 - est2,
      se = sqrt(max(diff_var, 0))
    )]
  }
  
  # Compute difference of difference tests (e.g., diff in top-bottom between two regressions)
  # For top-bottom: (G_n1 - G_11) - (G_n2 - G_12) = (G_n1 - G_n2) - (G_11 - G_12)
  # Need the full covariance structure
  
  top_col <- paste0("group_", n_groups)
  bottom_col <- "group_1"
  
  top_idx1 <- which(rownames(reg1$coef) == top_col)
  bottom_idx1 <- which(rownames(reg1$coef) == bottom_col)
  top_idx2 <- which(rownames(reg2$coef) == top_col)
  bottom_idx2 <- which(rownames(reg2$coef) == bottom_col)
  
  # Estimates of top-bottom for each regression
  tb1 <- reg1$coef[top_col, 1] - reg1$coef[bottom_col, 1]
  tb2 <- reg2$coef[top_col, 1] - reg2$coef[bottom_col, 1]
  diff_tb_est <- tb1 - tb2
  
  # Build covariance structure for [top1, bottom1, top2, bottom2]
  vcov1 <- reg1$vcov
  vcov2 <- reg2$vcov
  
  full_cov <- matrix(0, 4, 4)
  # Variances and covariances within reg1
  full_cov[1, 1] <- vcov1[top_col, top_col]
  full_cov[2, 2] <- vcov1[bottom_col, bottom_col]
  full_cov[1, 2] <- full_cov[2, 1] <- vcov1[top_col, bottom_col]
  # Variances and covariances within reg2
  full_cov[3, 3] <- vcov2[top_col, top_col]
  full_cov[4, 4] <- vcov2[bottom_col, bottom_col]
  full_cov[3, 4] <- full_cov[4, 3] <- vcov2[top_col, bottom_col]
  # Cross-covariances
  full_cov[1, 3] <- full_cov[3, 1] <- cross_cov[top_idx1, top_idx2]
  full_cov[1, 4] <- full_cov[4, 1] <- cross_cov[top_idx1, bottom_idx2]
  full_cov[2, 3] <- full_cov[3, 2] <- cross_cov[bottom_idx1, top_idx2]
  full_cov[2, 4] <- full_cov[4, 2] <- cross_cov[bottom_idx1, bottom_idx2]
  
  # Contrast for (top1 - bottom1) - (top2 - bottom2) = top1 - bottom1 - top2 + bottom2
  contrast_tb <- c(1, -1, -1, 1)
  diff_tb_var <- as.numeric(t(contrast_tb) %*% full_cov %*% contrast_tb)
  diff_tb_se <- sqrt(max(diff_tb_var, 0))
  
  top_bottom_diff <- data.table(
    estimate = diff_tb_est,
    se = diff_tb_se
  )
  
  # --- Difference in "all" test ---
  # all = weighted average of groups (same weights for both)
  weights_all <- res1$all$weights[[1]]  # Group proportions (extract from list column)
  # Difference: sum(w_g * (G_g1 - G_g2))
  all_diff_est <- sum(weights_all * (res1$reg$coef[group_cols, 1] - res2$reg$coef[group_cols, 1]))
  
  # Build full covariance for all groups from both regressions
  # (g1_1, g2_1, ..., gn_1, g1_2, g2_2, ..., gn_2)
  full_cov_all <- matrix(0, 2 * n_groups, 2 * n_groups)
  # Reg1 block
  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      full_cov_all[i, j] <- vcov1[group_cols[i], group_cols[j]]
    }
  }
  # Reg2 block
  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      full_cov_all[n_groups + i, n_groups + j] <- vcov2[group_cols[i], group_cols[j]]
    }
  }
  # Cross block
  for (i in 1:n_groups) {
    for (j in 1:n_groups) {
      full_cov_all[i, n_groups + j] <- cross_cov[i, j]
      full_cov_all[n_groups + j, i] <- cross_cov[i, j]
    }
  }
  
  # Contrast: w_1, w_2, ..., w_n, -w_1, -w_2, ..., -w_n
  contrast_all <- c(weights_all, -weights_all)
  all_diff_var <- as.numeric(t(contrast_all) %*% full_cov_all %*% contrast_all)
  all_diff_se <- sqrt(max(all_diff_var, 0))
  
  all_diff <- data.table(
    estimate = all_diff_est,
    se = all_diff_se
  )
  
  # --- Difference in "top-all" test ---
  # top-all = G_n - weighted_avg = G_n - sum(w_g * G_g)
  # Difference: (G_n1 - all1) - (G_n2 - all2)
  # = G_n1 - sum(w * G_g1) - G_n2 + sum(w * G_g2)
  # Contrast: (1-w_n, -w_2, ..., -w_{n-1}, 1-w_n) for reg1, negated for reg2
  top_all1 <- res1$top_all$estimate
  top_all2 <- res2$top_all$estimate
  top_all_diff_est <- top_all1 - top_all2
  
  # Contrast for top-all in combined vector
  # For reg1: G_n - sum(w*G_g) -> coef on G_g is (1-w_n if g=n, else -w_g)
  contrast_ta1 <- rep(0, n_groups)
  for (g_idx in 1:n_groups) {
    if (g_idx == n_groups) {
      contrast_ta1[g_idx] <- 1 - weights_all[g_idx]
    } else {
      contrast_ta1[g_idx] <- -weights_all[g_idx]
    }
  }
  # For difference: reg1 - reg2, so multiply reg2 contrasts by -1
  contrast_ta <- c(contrast_ta1, -contrast_ta1)
  top_all_diff_var <- as.numeric(t(contrast_ta) %*% full_cov_all %*% contrast_ta)
  top_all_diff_se <- sqrt(max(top_all_diff_var, 0))
  
  top_all_diff <- data.table(
    estimate = top_all_diff_est,
    se = top_all_diff_se
  )
  
  list(
    group_diff = group_diff,
    top_bottom_diff = top_bottom_diff,
    all_diff = all_diff,
    top_all_diff = top_all_diff
  )
}


#' Compare GAVS: Unrestricted vs Restricted Ranking
#' 
#' @description
#' Compares Group Averages (GAVS) between an unrestricted strategy (ranking
#' predictions across the full sample) and a restricted strategy (ranking
#' predictions within strata of a stratification variable).
#' 
#' This function implements the analysis from Fava (2025) to test whether
#' ranking by predicted values within subgroups (e.g., income quintiles,
#' education levels) yields different targeting results than global ranking.
#' 
#' The key statistical challenge is computing correct standard errors for the
#' difference between the two strategies, since they use the same data. This
#' is handled by computing the cross-covariance between regression estimates.
#' 
#' @references
#' Fava, B. (2025). Training and Testing with Multiple Splits: A Central Limit
#' Theorem for Split-Sample Estimators. \emph{arXiv preprint arXiv:2511.04957}.
#' 
#' @param ensemble_fit An object of class \code{ensemble_hte_fit} from 
#'   \code{ensemble_hte()} or \code{ensemble_pred_fit} from \code{ensemble_pred()}.
#' @param strata The stratification variable defining groups for restricted ranking:
#'   \itemize{
#'     \item Character string: column name in the \code{data} used in the ensemble function
#'     \item Numeric/factor vector: strata indicator (must have same length as data)
#'   }
#' @param n_groups Number of groups to divide the sample into (default: 3)
#' @param outcome Either:
#'   \itemize{
#'     \item NULL (default): uses the same outcome as in the ensemble function
#'     \item Character string: column name in the \code{data} used in the ensemble function
#'     \item Numeric vector: custom outcome variable (must have appropriate length)
#'   }
#' @param subset For \code{ensemble_pred_fit} only. Controls which observations to use:
#'   \itemize{
#'     \item \code{NULL} (default): Smart default - uses training obs if \code{outcome = NULL}
#'       and subset training was used, otherwise uses all observations.
#'     \item \code{"train"}: Use only training observations.
#'     \item \code{"all"}: Use all observations.
#'   }
#'   Ignored for \code{ensemble_hte_fit}.
#' 
#' @return An object of class \code{gavs_compare_results} containing:
#' \itemize{
#'   \item unrestricted: \code{gavs_results} object for unrestricted strategy
#'   \item restricted: \code{gavs_results} object for restricted strategy
#'   \item difference: data.table with the difference (unrestricted - restricted)
#'     for each group, with properly computed standard errors
#'   \item top_bottom_diff: data.table with difference in top-bottom estimates
#'   \item strata_var: name of the stratification variable
#'   \item strata_levels: unique levels of the stratification variable
#'   \item n_groups: number of groups used
#'   \item outcome: the outcome variable used
#'   \item targeted_outcome: the outcome used for prediction
#'   \item fit_type: "hte" or "pred" depending on input
#'   \item n_used: number of observations used
#'   \item M: number of repetitions
#'   \item call: the function call
#' }
#' 
#' @examples
#' \dontrun{
#' # Fit ensemble
#' fit <- ensemble_hte(Y ~ X1 + X2, data = mydata, treatment = "D")
#' 
#' # Compare unrestricted vs restricted by income quintile
#' comparison <- gavs_compare(fit, strata = "income_quintile", n_groups = 5)
#' print(comparison)
#' 
#' # The difference shows how much GAVS estimates change when restricting
#' # ranking to within each income quintile
#' }
#' 
#' @export
gavs_compare <- function(ensemble_fit, strata, n_groups = 3, outcome = NULL, 
                         subset = NULL) {
  
  # Check input type and extract predictions accordingly
  if (inherits(ensemble_fit, "ensemble_hte_fit")) {
    predictions_list <- lapply(1:ensemble_fit$M, function(m) ensemble_fit$ite[[m]])
    fit_type <- "hte"
    has_train_idx <- FALSE
  } else if (inherits(ensemble_fit, "ensemble_pred_fit")) {
    predictions_list <- lapply(1:ensemble_fit$M, function(m) ensemble_fit$predictions[[m]])
    fit_type <- "pred"
    has_train_idx <- !is.null(ensemble_fit$train_idx) && 
                     !is.null(ensemble_fit$n_train) && 
                     ensemble_fit$n_train < ensemble_fit$n
  } else {
    stop("ensemble_fit must be of class 'ensemble_hte_fit' or 'ensemble_pred_fit'")
  }
  
  cl <- match.call()
  n <- ensemble_fit$n
  
  # Get targeted outcome from ensemble_fit
  targeted_outcome <- all.vars(ensemble_fit$formula)[1]
  
  # Determine which outcome to use
  using_default_outcome <- is.null(outcome)
  
  if (is.null(outcome)) {
    Y <- ensemble_fit$Y
    outcome_var <- targeted_outcome
  } else if (is.character(outcome)) {
    if (length(outcome) != 1) {
      stop("outcome must be a single column name or a numeric vector")
    }
    if (!outcome %in% names(ensemble_fit$data)) {
      stop(paste0("outcome '", outcome, "' not found in the data"))
    }
    Y <- ensemble_fit$data[[outcome]]
    outcome_var <- outcome
  } else if (is.numeric(outcome)) {
    if (length(outcome) != n) {
      stop(paste0("outcome vector has length ", length(outcome), 
                  " but data has ", n, " rows"))
    }
    Y <- outcome
    outcome_var <- "custom_outcome"
  } else {
    stop("outcome must be NULL, a character string, or a numeric vector")
  }
  
  # Process strata argument
  if (is.character(strata)) {
    if (length(strata) != 1) {
      stop("strata must be a single column name or a vector")
    }
    if (!strata %in% names(ensemble_fit$data)) {
      stop(paste0("strata '", strata, "' not found in the data"))
    }
    strata_vec <- ensemble_fit$data[[strata]]
    strata_var <- strata
  } else if (is.numeric(strata) || is.factor(strata)) {
    if (length(strata) != n) {
      stop(paste0("strata vector has length ", length(strata), 
                  " but data has ", n, " rows"))
    }
    strata_vec <- strata
    strata_var <- "custom_strata"
  } else {
    stop("strata must be a character string (column name) or a numeric/factor vector")
  }
  
  # Convert strata to factor if not already
  if (!is.factor(strata_vec)) {
    strata_vec <- as.factor(strata_vec)
  }
  strata_levels <- levels(strata_vec)
  
  # Determine which observations to use
  if (fit_type == "hte") {
    use_idx <- rep(TRUE, n)
  } else {
    if (is.null(subset)) {
      if (using_default_outcome && has_train_idx) {
        use_idx <- ensemble_fit$train_idx
      } else {
        use_idx <- rep(TRUE, n)
      }
    } else if (subset == "train") {
      if (!has_train_idx) {
        stop("subset = 'train' specified but no train_idx was used in ensemble_pred()")
      }
      use_idx <- ensemble_fit$train_idx
    } else if (subset == "all") {
      use_idx <- rep(TRUE, n)
      if (using_default_outcome && has_train_idx && any(is.na(Y))) {
        warning("Using all observations but outcome has NA values for non-training observations")
      }
    } else {
      stop("subset must be NULL, 'train', or 'all'")
    }
  }
  
  # Validate no NAs in outcome for used observations
  if (any(is.na(Y[use_idx]))) {
    stop("outcome has NA values for the observations being used")
  }
  
  # Validate no NAs in strata for used observations
  if (any(is.na(strata_vec[use_idx]))) {
    stop("strata has NA values for the observations being used")
  }
  
  n_used <- sum(use_idx)
  
  # Extract components from ensemble_fit
  splits <- ensemble_fit$splits
  M <- ensemble_fit$M
  
  # Compute GAVS for each repetition (both unrestricted and restricted)
  results_by_rep <- lapply(1:M, function(m) {
    # Unrestricted GAVS (no strata)
    gavs_unrest <- .gavs_single(
      Y = Y[use_idx],
      predicted_values = predictions_list[[m]][use_idx],
      fold = splits[[m]][use_idx],
      n_groups = n_groups,
      strata = NULL
    )
    
    # Restricted GAVS (with strata)
    gavs_rest <- .gavs_single(
      Y = Y[use_idx],
      predicted_values = predictions_list[[m]][use_idx],
      fold = splits[[m]][use_idx],
      n_groups = n_groups,
      strata = strata_vec[use_idx]
    )
    
    # Compute differences with proper SEs using helper
    diff_results <- .compute_reg_diff(gavs_unrest, gavs_rest, n_groups)
    
    list(
      unrestricted = gavs_unrest,
      restricted = gavs_rest,
      diff_results = diff_results
    )
  })
  
  # Aggregate unrestricted results
  all_unrest_group <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$group_estimates), 
                                 idcol = "repetition")
  unrest_combined <- all_unrest_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  unrest_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_tb <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$top_bottom), 
                              idcol = "repetition")
  unrest_tb <- all_unrest_tb[, .(estimate = mean(estimate), se = mean(se))]
  unrest_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_all <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$all), 
                               idcol = "repetition")
  unrest_all <- all_unrest_all[, .(estimate = mean(estimate), se = mean(se))]
  unrest_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_ta <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$top_all), 
                              idcol = "repetition")
  unrest_ta <- all_unrest_ta[, .(estimate = mean(estimate), se = mean(se))]
  unrest_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Aggregate restricted results
  all_rest_group <- rbindlist(lapply(results_by_rep, function(x) x$restricted$group_estimates), 
                               idcol = "repetition")
  rest_combined <- all_rest_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  rest_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_tb <- rbindlist(lapply(results_by_rep, function(x) x$restricted$top_bottom), 
                            idcol = "repetition")
  rest_tb <- all_rest_tb[, .(estimate = mean(estimate), se = mean(se))]
  rest_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_all <- rbindlist(lapply(results_by_rep, function(x) x$restricted$all), 
                             idcol = "repetition")
  rest_all <- all_rest_all[, .(estimate = mean(estimate), se = mean(se))]
  rest_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_ta <- rbindlist(lapply(results_by_rep, function(x) x$restricted$top_all), 
                            idcol = "repetition")
  rest_ta <- all_rest_ta[, .(estimate = mean(estimate), se = mean(se))]
  rest_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Aggregate difference results
  all_diff_group <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$group_diff), 
                               idcol = "repetition")
  diff_combined <- all_diff_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  diff_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_tb <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$top_bottom_diff), 
                            idcol = "repetition")
  diff_tb <- all_diff_tb[, .(estimate = mean(estimate), se = mean(se))]
  diff_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_all <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$all_diff), 
                             idcol = "repetition")
  diff_all <- all_diff_all[, .(estimate = mean(estimate), se = mean(se))]
  diff_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_ta <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$top_all_diff), 
                            idcol = "repetition")
  diff_ta <- all_diff_ta[, .(estimate = mean(estimate), se = mean(se))]
  diff_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Construct unrestricted gavs_results-like object
  unrestricted <- structure(
    list(
      estimates = unrest_combined,
      top_bottom = unrest_tb,
      all = unrest_all,
      top_all = unrest_ta,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = fit_type,
      n_used = n_used,
      M = M
    ),
    class = "gavs_results"
  )
  
  # Construct restricted gavs_results-like object
  restricted <- structure(
    list(
      estimates = rest_combined,
      top_bottom = rest_tb,
      all = rest_all,
      top_all = rest_ta,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = fit_type,
      n_used = n_used,
      M = M
    ),
    class = "gavs_results"
  )
  
  # Construct gavs_compare_results object
  structure(
    list(
      unrestricted = unrestricted,
      restricted = restricted,
      difference = diff_combined,
      top_bottom_diff = diff_tb,
      all_diff = diff_all,
      top_all_diff = diff_ta,
      strata_var = strata_var,
      strata_levels = strata_levels,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = fit_type,
      n_used = n_used,
      M = M,
      call = cl
    ),
    class = "gavs_compare_results"
  )
}


#' Print method for gavs_compare_results objects
#' @param x An object of class \code{gavs_compare_results} from \code{gavs_compare()}
#' @param ... Additional arguments (currently unused)
#' @export
print.gavs_compare_results <- function(x, ...) {
  cat("\n")
  cat("GAVS Comparison: Unrestricted vs Restricted Ranking\n")
  cat(paste0(rep("=", 52), collapse = ""), "\n\n")
  
  # Basic info
  cat("Strategy comparison:\n")
  cat("  - Unrestricted: Rank predictions across full sample within folds\n")
  cat(paste0("  - Restricted: Rank predictions within strata ('", x$strata_var, "')\n"))
  cat(paste0("  - Strata levels: ", paste(x$strata_levels, collapse = ", "), "\n\n"))
  
  pred_type <- if (x$fit_type == "hte") "predicted ITE" else "predicted Y"
  cat(paste0("Groups (", x$n_groups, ") defined by: ", pred_type, "\n"))
  cat(paste0("Outcome: ", x$outcome, "\n"))
  if (x$outcome != x$targeted_outcome) {
    cat(paste0("Note: outcome differs from targeted outcome (", x$targeted_outcome, ")\n"))
  }
  cat(paste0("Observations: ", x$n_used, "\n"))
  cat(paste0("Repetitions: ", x$M, "\n\n"))
  
  # Unrestricted estimates
  cat("Unrestricted GAVS Estimates:\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$unrestricted$estimates[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$unrestricted$estimates$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom: ", sprintf("%.4f", x$unrestricted$top_bottom$estimate),
             " (SE: ", sprintf("%.4f", x$unrestricted$top_bottom$se), ", ",
             "p = ", sprintf("%.4f", x$unrestricted$top_bottom$p_value), ")\n"))
  if (!is.null(x$unrestricted$all)) {
    cat(paste0("All: ", sprintf("%.4f", x$unrestricted$all$estimate),
               " (SE: ", sprintf("%.4f", x$unrestricted$all$se), ", ",
               "p = ", sprintf("%.4f", x$unrestricted$all$p_value), ")\n"))
  }
  if (!is.null(x$unrestricted$top_all)) {
    cat(paste0("Top-All: ", sprintf("%.4f", x$unrestricted$top_all$estimate),
               " (SE: ", sprintf("%.4f", x$unrestricted$top_all$se), ", ",
               "p = ", sprintf("%.4f", x$unrestricted$top_all$p_value), ")\n"))
  }
  cat("\n")
  
  # Restricted estimates
  cat("Restricted GAVS Estimates:\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$restricted$estimates[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$restricted$estimates$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom: ", sprintf("%.4f", x$restricted$top_bottom$estimate),
             " (SE: ", sprintf("%.4f", x$restricted$top_bottom$se), ", ",
             "p = ", sprintf("%.4f", x$restricted$top_bottom$p_value), ")\n"))
  if (!is.null(x$restricted$all)) {
    cat(paste0("All: ", sprintf("%.4f", x$restricted$all$estimate),
               " (SE: ", sprintf("%.4f", x$restricted$all$se), ", ",
               "p = ", sprintf("%.4f", x$restricted$all$p_value), ")\n"))
  }
  if (!is.null(x$restricted$top_all)) {
    cat(paste0("Top-All: ", sprintf("%.4f", x$restricted$top_all$estimate),
               " (SE: ", sprintf("%.4f", x$restricted$top_all$se), ", ",
               "p = ", sprintf("%.4f", x$restricted$top_all$p_value), ")\n"))
  }
  cat("\n")
  
  # Difference (Unrestricted - Restricted)
  cat("Difference (Unrestricted - Restricted):\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$difference[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$difference$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom Diff: ", sprintf("%.4f", x$top_bottom_diff$estimate),
             " (SE: ", sprintf("%.4f", x$top_bottom_diff$se), ", ",
             "p = ", sprintf("%.4f", x$top_bottom_diff$p_value), ")\n"))
  if (!is.null(x$all_diff)) {
    cat(paste0("All Diff: ", sprintf("%.4f", x$all_diff$estimate),
               " (SE: ", sprintf("%.4f", x$all_diff$se), ", ",
               "p = ", sprintf("%.4f", x$all_diff$p_value), ")\n"))
  }
  if (!is.null(x$top_all_diff)) {
    cat(paste0("Top-All Diff: ", sprintf("%.4f", x$top_all_diff$estimate),
               " (SE: ", sprintf("%.4f", x$top_all_diff$se), ", ",
               "p = ", sprintf("%.4f", x$top_all_diff$p_value), ")\n"))
  }
  
  cat("\n")
  cat("Signif. codes: '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1\n")
  
  invisible(x)
}


#' Plot method for gavs_compare_results objects
#' @param x An object of class \code{gavs_compare_results} from \code{gavs_compare()}
#' @param alpha Significance level for confidence intervals (default 0.05)
#' @param ... Additional arguments (currently unused)
#' @return A ggplot object (invisibly)
#' @importFrom ggplot2 ggplot aes geom_point geom_errorbar geom_hline
#'   labs theme_minimal theme element_text scale_x_continuous position_dodge
#' @export
plot.gavs_compare_results <- function(x, alpha = 0.05, ...) {
  
  z_val <- qnorm(1 - alpha / 2)
  conf_level <- (1 - alpha) * 100
  
  # Prepare unrestricted data
  unrest_data <- copy(x$unrestricted$estimates)
  unrest_data[, strategy := "Unrestricted"]
  unrest_data[, ci_lower := estimate - z_val * se]
  unrest_data[, ci_upper := estimate + z_val * se]
  
  # Prepare restricted data
  rest_data <- copy(x$restricted$estimates)
  rest_data[, strategy := "Restricted"]
  rest_data[, ci_lower := estimate - z_val * se]
  rest_data[, ci_upper := estimate + z_val * se]
  
  # Combine
  plot_data <- rbindlist(list(unrest_data, rest_data))
  plot_data[, strategy := factor(strategy, levels = c("Unrestricted", "Restricted"))]
  
  # Determine label for y-axis
  pred_type <- if (x$fit_type == "hte") "Predicted ITE" else "Predicted Y"
  
  # Calculate global mean for reference line
  global_mean <- mean(x$unrestricted$estimates$estimate)
  
  # Create comparison plot with dodge
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = group, y = estimate, 
                                                color = strategy, shape = strategy)) +
    ggplot2::geom_hline(yintercept = global_mean, linetype = "dashed", 
                        color = "blue", linewidth = 0.5, alpha = 0.7) +
    ggplot2::geom_point(position = ggplot2::position_dodge(width = 0.3), size = 3) +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = ci_lower, ymax = ci_upper),
      width = 0.15, linewidth = 0.5,
      position = ggplot2::position_dodge(width = 0.3)
    ) +
    ggplot2::annotate("text", x = x$n_groups + 0.6, y = global_mean, 
                      label = paste0("Mean = ", sprintf("%.3f", global_mean)),
                      hjust = 0, vjust = -0.5, size = 3, color = "blue") +
    ggplot2::scale_x_continuous(
      breaks = 1:x$n_groups,
      labels = paste0("G", 1:x$n_groups),
      limits = c(0.5, x$n_groups + 1.2)
    ) +
    ggplot2::scale_color_manual(values = c("Unrestricted" = "#2C3E50", "Restricted" = "#E74C3C")) +
    ggplot2::scale_shape_manual(values = c("Unrestricted" = 16, "Restricted" = 17)) +
    ggplot2::labs(
      title = "GAVS Comparison: Unrestricted vs Restricted",
      subtitle = paste0("Groups ranked by ", pred_type, 
                        " | Restricted by: ", x$strata_var),
      x = paste0("Group (", x$n_groups, " groups by ", pred_type, ")"),
      y = paste0("Average ", x$outcome),
      color = "Strategy",
      shape = "Strategy",
      caption = paste0(conf_level, "% confidence intervals. ", x$M, " repetitions. ",
                       x$n_used, " observations.")
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      axis.title = ggplot2::element_text(face = "bold"),
      legend.position = "bottom"
    )
  
  print(p)
  invisible(p)
}


#' Compare GATES: Unrestricted vs Restricted Ranking
#' 
#' @description
#' Compares Group Average Treatment Effects (GATES) between an unrestricted strategy 
#' (ranking predictions across the full sample) and a restricted strategy (ranking
#' predictions within strata of a stratification variable).
#' 
#' This function implements the analysis from Fava (2025) to test whether
#' ranking by predicted treatment effects within subgroups (e.g., income quintiles,
#' education levels) yields different treatment effect estimates than global ranking.
#' 
#' The key statistical challenge is computing correct standard errors for the
#' difference between the two strategies, since they use the same data. This
#' is handled by computing the cross-covariance between regression estimates.
#' 
#' @references
#' Fava, B. (2025). Training and Testing with Multiple Splits: A Central Limit
#' Theorem for Split-Sample Estimators. \emph{arXiv preprint arXiv:2511.04957}.
#' 
#' @param ensemble_fit An object of class \code{ensemble_hte_fit} from 
#'   \code{ensemble_hte()}.
#' @param strata The stratification variable defining groups for restricted ranking:
#'   \itemize{
#'     \item Character string: column name in the \code{data} used in the ensemble function
#'     \item Numeric/factor vector: strata indicator (must have same length as data)
#'   }
#' @param n_groups Number of groups to divide the sample into (default: 3)
#' @param outcome Either:
#'   \itemize{
#'     \item NULL (default): uses the same outcome as in the ensemble function
#'     \item Character string: column name in the \code{data} used in the ensemble function
#'     \item Numeric vector: custom outcome variable (must have appropriate length)
#'   }
#' @param controls Optional character vector of control variable names from \code{data}
#'   to include as covariates in the GATES regression.
#' 
#' @return An object of class \code{gates_compare_results} containing:
#' \itemize{
#'   \item unrestricted: \code{gates_results} object for unrestricted strategy
#'   \item restricted: \code{gates_results} object for restricted strategy
#'   \item difference: data.table with the difference (unrestricted - restricted)
#'     for each group, with properly computed standard errors
#'   \item top_bottom_diff: data.table with difference in top-bottom estimates
#'   \item all_diff: data.table with difference in weighted average (all) estimates
#'   \item top_all_diff: data.table with difference in top-all estimates
#'   \item strata_var: name of the stratification variable
#'   \item strata_levels: unique levels of the stratification variable
#'   \item n_groups: number of groups used
#'   \item outcome: the outcome variable used
#'   \item targeted_outcome: the outcome used for prediction
#'   \item fit_type: "hte"
#'   \item n_used: number of observations used
#'   \item M: number of repetitions
#'   \item call: the function call
#' }
#' 
#' @examples
#' \dontrun{
#' # Fit ensemble
#' fit <- ensemble_hte(Y ~ X1 + X2, data = mydata, treatment = "D")
#' 
#' # Compare unrestricted vs restricted by income quintile
#' comparison <- gates_compare(fit, strata = "income_quintile", n_groups = 5)
#' print(comparison)
#' }
#' 
#' @export
gates_compare <- function(ensemble_fit, strata, n_groups = 3, outcome = NULL, 
                          controls = NULL) {
  
  # Check input type
  if (!inherits(ensemble_fit, "ensemble_hte_fit")) {
    stop("ensemble_fit must be of class 'ensemble_hte_fit'")
  }
  
  cl <- match.call()
  n <- ensemble_fit$n
  
  # Get targeted outcome from ensemble_fit
  targeted_outcome <- all.vars(ensemble_fit$formula)[1]
  
  # Determine which outcome to use
  if (is.null(outcome)) {
    Y <- ensemble_fit$Y
    outcome_var <- targeted_outcome
  } else if (is.character(outcome)) {
    if (length(outcome) != 1) {
      stop("outcome must be a single column name or a numeric vector")
    }
    if (!outcome %in% names(ensemble_fit$data)) {
      stop(paste0("outcome '", outcome, "' not found in the data"))
    }
    Y <- ensemble_fit$data[[outcome]]
    outcome_var <- outcome
  } else if (is.numeric(outcome)) {
    if (length(outcome) != n) {
      stop(paste0("outcome vector has length ", length(outcome), 
                  " but data has ", n, " rows"))
    }
    Y <- outcome
    outcome_var <- "custom_outcome"
  } else {
    stop("outcome must be NULL, a character string, or a numeric vector")
  }
  
  # Process strata argument
  if (is.character(strata)) {
    if (length(strata) != 1) {
      stop("strata must be a single column name or a vector")
    }
    if (!strata %in% names(ensemble_fit$data)) {
      stop(paste0("strata '", strata, "' not found in the data"))
    }
    strata_vec <- ensemble_fit$data[[strata]]
    strata_var <- strata
  } else if (is.numeric(strata) || is.factor(strata)) {
    if (length(strata) != n) {
      stop(paste0("strata vector has length ", length(strata), 
                  " but data has ", n, " rows"))
    }
    strata_vec <- strata
    strata_var <- "custom_strata"
  } else {
    stop("strata must be a character string (column name) or a numeric/factor vector")
  }
  
  # Convert strata to factor if not already
  if (!is.factor(strata_vec)) {
    strata_vec <- as.factor(strata_vec)
  }
  strata_levels <- levels(strata_vec)
  
  # Validate no NAs in outcome
  if (any(is.na(Y))) {
    stop("outcome has NA values")
  }
  
  # Validate no NAs in strata
  if (any(is.na(strata_vec))) {
    stop("strata has NA values")
  }
  
  n_used <- n
  
  # Get treatment variable
  D <- ensemble_fit$data[[ensemble_fit$treatment]]
  
  # Set up propensity score (default = 0.5 for balanced experiments)
  prop_score <- rep(0.5, n)
  
  # Compute IPW weights
  W <- D / prop_score + (1 - D) / (1 - prop_score)
  
  # Get controls data if specified
  if (!is.null(controls)) {
    if (!is.character(controls)) {
      stop("controls must be a character vector of column names")
    }
    missing_controls <- controls[!controls %in% names(ensemble_fit$data)]
    if (length(missing_controls) > 0) {
      stop(paste0("Control variable(s) not found in data: ", 
                  paste(missing_controls, collapse = ", ")))
    }
    control_data <- ensemble_fit$data[, ..controls]
  } else {
    control_data <- NULL
  }
  
  # Extract components from ensemble_fit
  predictions_list <- lapply(1:ensemble_fit$M, function(m) ensemble_fit$ite[[m]])
  splits <- ensemble_fit$splits
  M <- ensemble_fit$M
  
  # Compute GATES for each repetition (both unrestricted and restricted)
  results_by_rep <- lapply(1:M, function(m) {
    # Unrestricted GATES (no strata)
    gates_unrest <- .gates_single(
      Y = Y,
      D = D,
      prop_score = prop_score,
      weight = W,
      predicted_values = predictions_list[[m]],
      fold = splits[[m]],
      n_groups = n_groups,
      controls = control_data,
      strata = NULL
    )
    
    # Restricted GATES (with strata)
    gates_rest <- .gates_single(
      Y = Y,
      D = D,
      prop_score = prop_score,
      weight = W,
      predicted_values = predictions_list[[m]],
      fold = splits[[m]],
      n_groups = n_groups,
      controls = control_data,
      strata = strata_vec
    )
    
    # Compute differences with proper SEs using helper
    diff_results <- .compute_reg_diff(gates_unrest, gates_rest, n_groups)
    
    list(
      unrestricted = gates_unrest,
      restricted = gates_rest,
      diff_results = diff_results
    )
  })
  
  # Aggregate unrestricted results
  all_unrest_group <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$group_estimates), 
                                 idcol = "repetition")
  unrest_combined <- all_unrest_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  unrest_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_tb <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$top_bottom), 
                              idcol = "repetition")
  unrest_tb <- all_unrest_tb[, .(estimate = mean(estimate), se = mean(se))]
  unrest_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_all <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$all), 
                               idcol = "repetition")
  unrest_all <- all_unrest_all[, .(estimate = mean(estimate), se = mean(se))]
  unrest_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_unrest_ta <- rbindlist(lapply(results_by_rep, function(x) x$unrestricted$top_all), 
                              idcol = "repetition")
  unrest_ta <- all_unrest_ta[, .(estimate = mean(estimate), se = mean(se))]
  unrest_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Aggregate restricted results
  all_rest_group <- rbindlist(lapply(results_by_rep, function(x) x$restricted$group_estimates), 
                               idcol = "repetition")
  rest_combined <- all_rest_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  rest_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_tb <- rbindlist(lapply(results_by_rep, function(x) x$restricted$top_bottom), 
                            idcol = "repetition")
  rest_tb <- all_rest_tb[, .(estimate = mean(estimate), se = mean(se))]
  rest_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_all <- rbindlist(lapply(results_by_rep, function(x) x$restricted$all), 
                             idcol = "repetition")
  rest_all <- all_rest_all[, .(estimate = mean(estimate), se = mean(se))]
  rest_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_rest_ta <- rbindlist(lapply(results_by_rep, function(x) x$restricted$top_all), 
                            idcol = "repetition")
  rest_ta <- all_rest_ta[, .(estimate = mean(estimate), se = mean(se))]
  rest_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Aggregate difference results
  all_diff_group <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$group_diff), 
                               idcol = "repetition")
  diff_combined <- all_diff_group[, .(
    estimate = mean(estimate),
    se = mean(se),
    n_reps = .N
  ), by = group]
  diff_combined[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_tb <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$top_bottom_diff), 
                            idcol = "repetition")
  diff_tb <- all_diff_tb[, .(estimate = mean(estimate), se = mean(se))]
  diff_tb[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_all <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$all_diff), 
                             idcol = "repetition")
  diff_all <- all_diff_all[, .(estimate = mean(estimate), se = mean(se))]
  diff_all[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  all_diff_ta <- rbindlist(lapply(results_by_rep, function(x) x$diff_results$top_all_diff), 
                            idcol = "repetition")
  diff_ta <- all_diff_ta[, .(estimate = mean(estimate), se = mean(se))]
  diff_ta[, `:=`(t_value = estimate / se, p_value = 2 * pnorm(-abs(estimate / se)))]
  
  # Construct unrestricted gates_results-like object
  unrestricted <- structure(
    list(
      estimates = unrest_combined,
      top_bottom = unrest_tb,
      all = unrest_all,
      top_all = unrest_ta,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = "hte",
      controls = controls,
      n_used = n_used,
      M = M
    ),
    class = "gates_results"
  )
  
  # Construct restricted gates_results-like object
  restricted <- structure(
    list(
      estimates = rest_combined,
      top_bottom = rest_tb,
      all = rest_all,
      top_all = rest_ta,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = "hte",
      controls = controls,
      n_used = n_used,
      M = M
    ),
    class = "gates_results"
  )
  
  # Construct gates_compare_results object
  structure(
    list(
      unrestricted = unrestricted,
      restricted = restricted,
      difference = diff_combined,
      top_bottom_diff = diff_tb,
      all_diff = diff_all,
      top_all_diff = diff_ta,
      strata_var = strata_var,
      strata_levels = strata_levels,
      n_groups = n_groups,
      outcome = outcome_var,
      targeted_outcome = targeted_outcome,
      fit_type = "hte",
      controls = controls,
      n_used = n_used,
      M = M,
      call = cl
    ),
    class = "gates_compare_results"
  )
}


#' Print method for gates_compare_results objects
#' @param x An object of class \code{gates_compare_results} from \code{gates_compare()}
#' @param ... Additional arguments (currently unused)
#' @export
print.gates_compare_results <- function(x, ...) {
  cat("\n")
  cat("GATES Comparison: Unrestricted vs Restricted Ranking\n")
  cat(paste0(rep("=", 53), collapse = ""), "\n\n")
  
  # Basic info
  cat("Strategy comparison:\n")
  cat("  - Unrestricted: Rank predictions across full sample within folds\n")
  cat(paste0("  - Restricted: Rank predictions within strata ('", x$strata_var, "')\n"))
  cat(paste0("  - Strata levels: ", paste(x$strata_levels, collapse = ", "), "\n\n"))
  
  cat(paste0("Groups (", x$n_groups, ") defined by: predicted ITE\n"))
  cat(paste0("Outcome: ", x$outcome, "\n"))
  if (x$outcome != x$targeted_outcome) {
    cat(paste0("Note: outcome differs from targeted outcome (", x$targeted_outcome, ")\n"))
  }
  if (!is.null(x$controls)) {
    cat("Controls:", paste(x$controls, collapse = ", "), "\n")
  }
  cat(paste0("Observations: ", x$n_used, "\n"))
  cat(paste0("Repetitions: ", x$M, "\n\n"))
  
  # Unrestricted estimates
  cat("Unrestricted GATES Estimates:\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$unrestricted$estimates[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$unrestricted$estimates$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom: ", sprintf("%.4f", x$unrestricted$top_bottom$estimate),
             " (SE: ", sprintf("%.4f", x$unrestricted$top_bottom$se), ", ",
             "p = ", sprintf("%.4f", x$unrestricted$top_bottom$p_value), ")\n"))
  if (!is.null(x$unrestricted$all)) {
    cat(paste0("All: ", sprintf("%.4f", x$unrestricted$all$estimate),
               " (SE: ", sprintf("%.4f", x$unrestricted$all$se), ", ",
               "p = ", sprintf("%.4f", x$unrestricted$all$p_value), ")\n"))
  }
  if (!is.null(x$unrestricted$top_all)) {
    cat(paste0("Top-All: ", sprintf("%.4f", x$unrestricted$top_all$estimate),
               " (SE: ", sprintf("%.4f", x$unrestricted$top_all$se), ", ",
               "p = ", sprintf("%.4f", x$unrestricted$top_all$p_value), ")\n"))
  }
  cat("\n")
  
  # Restricted estimates
  cat("Restricted GATES Estimates:\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$restricted$estimates[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$restricted$estimates$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom: ", sprintf("%.4f", x$restricted$top_bottom$estimate),
             " (SE: ", sprintf("%.4f", x$restricted$top_bottom$se), ", ",
             "p = ", sprintf("%.4f", x$restricted$top_bottom$p_value), ")\n"))
  if (!is.null(x$restricted$all)) {
    cat(paste0("All: ", sprintf("%.4f", x$restricted$all$estimate),
               " (SE: ", sprintf("%.4f", x$restricted$all$se), ", ",
               "p = ", sprintf("%.4f", x$restricted$all$p_value), ")\n"))
  }
  if (!is.null(x$restricted$top_all)) {
    cat(paste0("Top-All: ", sprintf("%.4f", x$restricted$top_all$estimate),
               " (SE: ", sprintf("%.4f", x$restricted$top_all$se), ", ",
               "p = ", sprintf("%.4f", x$restricted$top_all$p_value), ")\n"))
  }
  cat("\n")
  
  # Difference (Unrestricted - Restricted)
  cat("Difference (Unrestricted - Restricted):\n")
  cat(paste0(rep("-", 40), collapse = ""), "\n")
  print_df <- as.data.frame(x$difference[, .(group, estimate, se, t_value, p_value)])
  print_df$estimate <- sprintf("%.4f", print_df$estimate)
  print_df$se <- sprintf("%.4f", print_df$se)
  print_df$t_value <- sprintf("%.2f", print_df$t_value)
  print_df$p_value <- sprintf("%.4f", as.numeric(print_df$p_value))
  print_df$sig <- sapply(as.numeric(x$difference$p_value), get_stars)
  names(print_df) <- c("Group", "Estimate", "SE", "t", "p-value", "")
  print(print_df, row.names = FALSE, right = FALSE)
  
  cat("\n")
  cat(paste0("Top-Bottom Diff: ", sprintf("%.4f", x$top_bottom_diff$estimate),
             " (SE: ", sprintf("%.4f", x$top_bottom_diff$se), ", ",
             "p = ", sprintf("%.4f", x$top_bottom_diff$p_value), ")\n"))
  if (!is.null(x$all_diff)) {
    cat(paste0("All Diff: ", sprintf("%.4f", x$all_diff$estimate),
               " (SE: ", sprintf("%.4f", x$all_diff$se), ", ",
               "p = ", sprintf("%.4f", x$all_diff$p_value), ")\n"))
  }
  if (!is.null(x$top_all_diff)) {
    cat(paste0("Top-All Diff: ", sprintf("%.4f", x$top_all_diff$estimate),
               " (SE: ", sprintf("%.4f", x$top_all_diff$se), ", ",
               "p = ", sprintf("%.4f", x$top_all_diff$p_value), ")\n"))
  }
  
  cat("\n")
  cat("Signif. codes: '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1\n")
  
  invisible(x)
}


#' Plot method for gates_compare_results objects
#' @param x An object of class \code{gates_compare_results} from \code{gates_compare()}
#' @param alpha Significance level for confidence intervals (default 0.05)
#' @param ... Additional arguments (currently unused)
#' @return A ggplot object (invisibly)
#' @importFrom ggplot2 ggplot aes geom_point geom_errorbar geom_hline
#'   labs theme_minimal theme element_text scale_x_continuous position_dodge
#' @export
plot.gates_compare_results <- function(x, alpha = 0.05, ...) {
  
  z_val <- qnorm(1 - alpha / 2)
  conf_level <- (1 - alpha) * 100
  
  # Prepare unrestricted data
  unrest_data <- copy(x$unrestricted$estimates)
  unrest_data[, strategy := "Unrestricted"]
  unrest_data[, ci_lower := estimate - z_val * se]
  unrest_data[, ci_upper := estimate + z_val * se]
  
  # Prepare restricted data
  rest_data <- copy(x$restricted$estimates)
  rest_data[, strategy := "Restricted"]
  rest_data[, ci_lower := estimate - z_val * se]
  rest_data[, ci_upper := estimate + z_val * se]
  
  # Combine
  plot_data <- rbindlist(list(unrest_data, rest_data))
  plot_data[, strategy := factor(strategy, levels = c("Unrestricted", "Restricted"))]
  
  # Calculate global ATE for reference line
  global_ate <- mean(x$unrestricted$estimates$estimate)
  
  # Create comparison plot with dodge
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = group, y = estimate, 
                                                color = strategy, shape = strategy)) +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "gray50") +
    ggplot2::geom_hline(yintercept = global_ate, linetype = "solid", 
                        color = "blue", linewidth = 0.5, alpha = 0.7) +
    ggplot2::geom_point(position = ggplot2::position_dodge(width = 0.3), size = 3) +
    ggplot2::geom_errorbar(
      ggplot2::aes(ymin = ci_lower, ymax = ci_upper),
      width = 0.15, linewidth = 0.5,
      position = ggplot2::position_dodge(width = 0.3)
    ) +
    ggplot2::annotate("text", x = x$n_groups + 0.6, y = global_ate, 
                      label = paste0("ATE = ", sprintf("%.3f", global_ate)),
                      hjust = 0, vjust = -0.5, size = 3, color = "blue") +
    ggplot2::scale_x_continuous(
      breaks = 1:x$n_groups,
      labels = paste0("G", 1:x$n_groups),
      limits = c(0.5, x$n_groups + 1.2)
    ) +
    ggplot2::scale_color_manual(values = c("Unrestricted" = "#2C3E50", "Restricted" = "#E74C3C")) +
    ggplot2::scale_shape_manual(values = c("Unrestricted" = 16, "Restricted" = 17)) +
    ggplot2::labs(
      title = "GATES Comparison: Unrestricted vs Restricted",
      subtitle = paste0("Groups ranked by Predicted ITE", 
                        " | Restricted by: ", x$strata_var),
      x = paste0("Group (", x$n_groups, " groups by Predicted ITE)"),
      y = "Treatment Effect",
      color = "Strategy",
      shape = "Strategy",
      caption = paste0(conf_level, "% confidence intervals. ", x$M, " repetitions. ",
                       x$n_used, " observations.")
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold"),
      axis.title = ggplot2::element_text(face = "bold"),
      legend.position = "bottom"
    )
  
  print(p)
  invisible(p)
}

