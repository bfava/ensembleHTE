## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## ----simulate-data------------------------------------------------------------
# library(ensembleHTE)
# 
# # Set seed for reproducibility
# set.seed(123)
# 
# # Generate data
# n <- 500
# X1 <- rnorm(n)
# X2 <- rnorm(n)
# X3 <- rbinom(n, 1, 0.5)
# D <- rbinom(n, 1, 0.5)  # Treatment
# 
# # Heterogeneous treatment effect
# tau <- 1 + 0.5 * X1
# Y <- 0.5 * X1 + 0.3 * X2 + D * tau + rnorm(n, sd = 0.5)
# 
# data <- data.frame(Y = Y, D = D, X1 = X1, X2 = X2, X3 = X3)

## ----fit-model----------------------------------------------------------------
# # Fit ensemble HTE model
# fit <- ensemble_hte(
#   formula = Y ~ X1 + X2 + X3,
#   treatment = D,
#   data = data,
#   algorithms = c("lm", "grf"),
#   M = 5,  # Number of repetitions
#   K = 3   # Number of cross-fitting folds
# )
# 
# # View results
# print(fit)
# summary(fit)

## ----analysis-----------------------------------------------------------------
# # Best Linear Predictor (BLP)
# blp_results <- blp(fit)
# print(blp_results)
# 
# # Group Average Treatment Effects (GATES)
# gates_results <- gates(fit, n_groups = 3)
# print(gates_results)
# plot(gates_results)
# 
# # Classification Analysis (CLAN)
# clan_results <- clan(fit)
# print(clan_results)
# plot(clan_results)

## ----prediction---------------------------------------------------------------
# # Fit ensemble prediction model
# pred_fit <- ensemble_pred(
#   formula = Y ~ X1 + X2 + X3,
#   data = data,
#   algorithms = c("lm", "grf"),
#   M = 5, K = 3
# )
# 
# # Analyze predictions
# summary(pred_fit)
# 
# # Group Averages
# gavs_results <- gavs(pred_fit, n_groups = 3)
# print(gavs_results)
# plot(gavs_results)

## ----compare------------------------------------------------------------------
# # Add a stratification variable
# data$income_group <- sample(c("low", "mid", "high"), n, replace = TRUE)
# 
# # Fit model
# fit <- ensemble_hte(
#   formula = Y ~ X1 + X2 + X3,
#   treatment = D,
#   data = data,
#   M = 5, K = 3
# )
# 
# # Compare ranking strategies
# comparison <- gates_compare(fit, strata = "income_group", n_groups = 3)
# print(comparison)
# plot(comparison)

