library(testthat)
library(ensembleHTE)

test_check("ensembleHTE")
